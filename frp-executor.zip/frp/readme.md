# 添加域名解析

``` bash
#linux平台 在/etc/hosts文件中增加一条记录
#windows平台 在C:\Windows\System32\drivers\etc\hosts文件中增加一条记录
#你的代理服务器的ip  server.example.com
```

# 修改启动命令

```
--proxy_host 192.168.1.5 --proxy_port 8080 修改为你想要被外网访问的对应服务的ip和端口信息
```
