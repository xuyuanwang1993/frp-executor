#!/bin/bash
./frp_proxy_client -i server.example.com --proxy_host 192.168.1.5 --proxy_port 8080 --ca ca_root.crt 