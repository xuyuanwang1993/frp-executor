#!/bin/bash
./frp_proxy_server -p 32000 --ca ca_root.crt --pem local.crt --key local.key
